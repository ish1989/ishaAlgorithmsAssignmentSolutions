package com.greatlearning.Stockers.Driver;

import java.util.Scanner;

import com.greatlearning.Stockers.Operations.*;

public class DriverStocker {

	public static void main(String arg[])
	{   
		int NoOfCompanies;
		double StockPrice[];
		Boolean PriceTrack[];

		System.out.println("Enter the number of Companies");

		Scanner sc=new Scanner(System.in);
		NoOfCompanies=sc.nextInt();
		StockPrice=new double[NoOfCompanies];//Stock price of different companies from console	
		PriceTrack=new Boolean[NoOfCompanies];//Price change track of different companies from console

		for(int i =0;i<StockPrice.length;i++)
		{
			System.out.println("Enter the current stock price of the company "+(i+1));
			StockPrice[i]=sc.nextDouble();
			System.out.println("Whether Company's stock price rose today compare to yesterday ?");
			PriceTrack[i]=sc.nextBoolean();
		}
		/*Object creation of all the operation classes*/
		AscendingSort ascendingsort=new AscendingSort();
		DesendingSort descendingsort=new DesendingSort();
		PriceStockRose pricestockrose=new PriceStockRose();
		PriceStockDeclined pricestockdeclined=new PriceStockDeclined();
		Search search=new Search();



		/*Infinite loop for menu---press 0 to exit*/
		while(0<1)
		{
			System.out.println("\n------------------------------\n");
			System.out.println("Enter the operation that you want to perform");
			System.out.println("1.Display the companies stock prices in ascending order");
			System.out.println("2.Display the companies stock prices in descending order");
			System.out.println("3.Display the total no. of companies for which stock prices rose today");
			System.out.println("4.Display the  total no.of companies for which stock prices declined today");
			System.out.println("5.Search the specific stock price ");
			System.out.println("6.press 0 to exit");
			System.out.println("\n------------------------------\n");
			int choice=sc.nextInt();
			System.out.println("\n");

			switch(choice)

			{
			case 1: 
			{
				ascendingsort.Sorting(StockPrice);
				break;
			}
		


			case 2: 
			{
				descendingsort.Sorting(StockPrice);

				break;
			}
			case 3:
			{
				pricestockrose.priceStock(PriceTrack);
				break;
			}

			case 4:
			{
				pricestockdeclined.priceStock(PriceTrack);

				break;
			}

			case 5:
			{

				System.out.println("Enter the key Value");
				double keyValue=sc.nextDouble();
				int result=search.searchStock(StockPrice,0,StockPrice.length,keyValue);


				if (result == -1)
					System.out.println("Search stock price is not found");
				else
					System.out.println("Search stock price is found");
				break;
			}




			case 6:
			{
				System.out.println("Please enter 0 to exit");
				break;
			}

			case 0:
			{	
				System.out.println("Exited Successfully ...");
				System.exit(0);
			}

			default: System.out.println("Enter the appropriate choice");


			sc.close();

			}}

	}
}
