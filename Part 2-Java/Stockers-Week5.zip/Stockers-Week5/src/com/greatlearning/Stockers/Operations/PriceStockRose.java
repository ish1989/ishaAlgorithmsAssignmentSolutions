package com.greatlearning.Stockers.Operations;

public class PriceStockRose{

	public void priceStock(Boolean pricestock[])
	{		

		int Rose=0;

		for(int i =0;i<pricestock.length;i++) 
		{
			if(pricestock[i]==true)
			{
				Rose++;
			}


		}
		if (Rose==0)
			System.out.println("Total no.of companies whose stock price rose today : " +0);
		else
			System.out.println("Total no.of companies whose stock price rose today :" +Rose);
	}


}
