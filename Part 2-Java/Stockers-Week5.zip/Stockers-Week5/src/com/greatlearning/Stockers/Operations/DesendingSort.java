package com.greatlearning.Stockers.Operations;



public class DesendingSort {

	double array[];
	int length;

	public void Sorting(double arr[])
	{
		this.array=arr;
		this.length=arr.length;

		divideArray(0,length-1);//calling divide method to divide the array
		System.out.println("Stocks in descending order are :\n ");

		for(int i =0;i<length;i++ )
			System.out.print(" " +array[i]+ " ");


	}

	public void divideArray(int lowerbound,int upperbound)
	{
		if(lowerbound<upperbound)
		{
			int mid=lowerbound+(upperbound-lowerbound)/2;
			divideArray(lowerbound,mid);// dividing left side of array-recursive
			divideArray(mid+1,upperbound);//dividing right side of array-recursive
			mergeSort(lowerbound,mid,upperbound);//calling mergesort to combine the array
		}
	}

	public void mergeSort(int lowerbound,int mid,int upperbound)
	{
		int subArrayLeft=mid-lowerbound+1;
		int subArrayRight=upperbound-mid;//subarray size
		double Left[]=new  double[subArrayLeft];
		double Right[]=new double[subArrayRight];

		for(int i=0;i<subArrayLeft;i++)
		{
			Left[i]=array[lowerbound+i];
		}

		for(int j=0;j<subArrayRight;j++)
		{
			Right[j]=array[mid+1+j];
		}

		int i=0,j=0,k=lowerbound;
		while(i<subArrayLeft && j<subArrayRight)

		{
			if(Left[i]>=Right[j])


			{
				array[k]=Left[i];
				i++;

			}
			else
			{
				array[k]=Right[j];
				j++;
			}

			k++;
		}

		while(i<subArrayLeft) {
			array[k]=Left[i];
			i++;
			k++;

		}
		while(j<subArrayRight) {
			array[k]=Right[j];
			j++;
			k++;

		}
	}}




