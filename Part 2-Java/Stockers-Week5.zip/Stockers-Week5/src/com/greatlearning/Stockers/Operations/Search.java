package com.greatlearning.Stockers.Operations;

import java.util.Scanner;

public class Search {

	Scanner sc=new Scanner(System.in);

	public int searchStock(double StockPrice[],int lowerbound,int higherbound,double keyValue)
	{	

		if(lowerbound<=higherbound-1)
		{
			int mid=lowerbound+(higherbound-lowerbound)/2;

			if(StockPrice[mid]==keyValue)
			{

				return mid;
			}	
			if (StockPrice[mid]<keyValue)

				return searchStock(StockPrice,0,mid-1,keyValue);

			return searchStock(StockPrice,mid+1,higherbound,keyValue);




		}
		return -1;
	}

}
