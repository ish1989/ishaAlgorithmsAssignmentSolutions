package com.greatlearning.Stockers.Operations;

public class PriceStockDeclined {

	public void priceStock(Boolean pricestock[])
	{		
		int decline=0;

		for(int i =0;i<pricestock.length;i++) 
		{
			if(pricestock[i]==false)
			{
				decline++;
			}


		}
		if (decline==0)
			System.out.println("Total no.of companies whose stock price fallen today : " +0);
		else
			System.out.println("Total no.of companies whose stock price fallen today :" +decline);
	}



}

